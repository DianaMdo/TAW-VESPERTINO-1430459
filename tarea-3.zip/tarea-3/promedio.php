<?php
    //defnir clase persona
    class alumnos{
        //definir propiedades
        public $diana1;
        public $diana2;
        public $diana3;
        public $resultado_diana;

        public $isra1;
        public $isra2;
        public $isra3;
        public $resultado_isra;

        public $luis1;
        public $luis2;
        public $luis3;
        public $resultado_luis;

        public $cesar1;
        public $cesar2;
        public $cesar3;
        public $resultado_cesar;

        public $marcelo1;
        public $marcelo2;
        public $marcelo3;
        public $resultado_marcelo;

        public $grecia1;
        public $grecia2;
        public $grecia3;
        public $resultado_grecia;

        public $jaret1;
        public $jaret2;
        public $jaret3;
        public $resultado_jaret;

        public $juan1;
        public $juan2;
        public $juan3;
        public $resultado_juan;

        public $sandra1;
        public $sandra2;
        public $sandra3;
        public $resultado_sandra;

        public $saul1;
        public $saul2;
        public $saul3;
        public $resultado_saul;



        //definir metodo obtencion de datos
        //getters
       
        public function getDiana1(){
            return $this->diana1;
        }
    
        public function getDiana2(){
            return $this->diana2;
        }

        public function getDiana3(){
            return $this->diana3;
        }

        //definir metodos asignacion de datos
        //setters

        public function setDiana1($valor){
            $this->diana1 = $valor;

        }

        public function setDiana2($valor){
            $this->diana2 = $valor;

        }

        
        public function setDiana3($valor){
            $this->diana3 = $valor;

        }
    }    
    //////////////////////////////////////////////////////////////////////////

    //definir metodo obtencion de datos
        //getters
       
        public function getIsra1(){
            return $this->isra1;
        }
    
        public function getIsra2(){
            return $this->isra2;
        }

        public function getIsra3(){
            return $this->isra3;
        }

        //definir metodos asignacion de datos
        //setters

        public function setIsra1($valor){
            $this->isra1 = $valor;

        }

        public function setIsra2($valor){
            $this->isra2 = $valor;

        }

        
        public function setIsra3($valor){
            $this->isra3 = $valor;

        }
    }    

    //////////////////////////////////////////////////////////////////////////

      //definir metodo obtencion de datos
        //getters
       
        public function getLuis1(){
            return $this->luis1;
        }
    
        public function getLuis1(){
            return $this->luis1;
        }

        public function getLuis1(){
            return $this->luis1;
        }

        //definir metodos asignacion de datos
        //setters

        public function setLuis1($valor){
            $this->luis1 = $valor;

        }

        public function setLuis2($valor){
            $this->luis2 = $valor;

        }

        
        public function setLuis3($valor){
            $this->luis3 = $valor;

        }
    }    

    //////////////////////////////////////////////////////////////////////////

      //definir metodo obtencion de datos
        //getters
       
        public function gtCesar1(){
            return $this->cesar1;
        }
    
        public function gtCesar2(){
            return $this->cesar2;
        }

        public function gtCesar3(){
            return $this->cesar3;
        }

        //definir metodos asignacion de datos
        //setters

        public function setCesar1($valor){
            $this->cesar1 = $valor;

        }

        public function setCesar2($valor){
            $this->cesar2 = $valor;

        }

        
        public function setCesar3($valor){
            $this->cesar3 = $valor;

        }
    }    

    //////////////////////////////////////////////////////////////////////////

      //definir metodo obtencion de datos
        //getters
       
        public function getMarcelo1(){
            return $this->marcelo1;
        }
    
        public function getMarcelo2(){
            return $this->marcelo2;
        }

        public function getMarcelo3(){
            return $this->marcelo3;
        }

        //definir metodos asignacion de datos
        //setters

        public function setMarcelo1($valor){
            $this->marcelo1 = $valor;

        }

        public function setMarcelo2($valor){
            $this->marcelo2 = $valor;

        }

        
        public function setMarcelo3($valor){
            $this->marcelo3 = $valor;

        }
    }    

    //////////////////////////////////////////////////////////////////////////


      //definir metodo obtencion de datos
        //getters
       
        public function getGrecia1(){
            return $this->grecia1;
        }
    
        public function getGrecia2(){
            return $this->grecia2;
        }

        public function getGrecia3(){
            return $this->grecia3;
        }

        //definir metodos asignacion de datos
        //setters

        public function setGrecia1($valor){
            $this->grecia1 = $valor;

        }

        public function setGrecia2($valor){
            $this->grecia2 = $valor;

        }

        
        public function setGrecia3($valor){
            $this->grecia3 = $valor;

        }
    }    

    //////////////////////////////////////////////////////////////////////////

      //definir metodo obtencion de datos
        //getters
       
        public function getJaret1(){
            return $this->jaret1;
        }
    
        public function getJaret2(){
            return $this->jaret2;
        }

        public function getJaret3(){
            return $this->jaret3;
        }

        //definir metodos asignacion de datos
        //setters

        public function setJaret1($valor){
            $this->jaret1 = $valor;

        }

        public function setJaret2($valor){
            $this->jaret2 = $valor;

        }

        
        public function setJaret3($valor){
            $this->jaret3 = $valor;

        }
    }    

    //////////////////////////////////////////////////////////////////////////

      //definir metodo obtencion de datos
        //getters
       
        public function getJuan1(){
            return $this->juan1;
        }
    
        public function getJuan2(){
            return $this->juan2;
        }

        public function getJuan3(){
            return $this->juan3;
        }

        //definir metodos asignacion de datos
        //setters

        public function setJuan1($valor){
            $this->juan1 = $valor;

        }

        public function setJuan2($valor){
            $this->juan2 = $valor;

        }

        
        public function setJuan3($valor){
            $this->juan3 = $valor;

        }
    }    

    //////////////////////////////////////////////////////////////////////////


      //definir metodo obtencion de datos
        //getters
       
        public function getSandra1(){
            return $this->sandra1;
        }
    
        public function getSandra2(){
            return $this->sandra2;
        }

        public function getSandra3(){
            return $this->sandra3;
        }

        //definir metodos asignacion de datos
        //setters

        public function setSandra1($valor){
            $this->sandra1 = $valor;

        }

        public function setSandra2($valor){
            $this->sandra2 = $valor;

        }

        
        public function setSandra3($valor){
            $this->sandra3 = $valor;

        }
    }    

    //////////////////////////////////////////////////////////////////////////

      //definir metodo obtencion de datos
        //getters
       
        public function getSaul(){
            return $this->saul1;
        }
    
        public function getSau2(){
            return $this->saul2;
        }

        public function getSaul3(){
            return $this->saul3;
        }

        //definir metodos asignacion de datos
        //setters

        public function setSaul1($valor){
            $this->saul1 = $valor;

        }

        public function setSaul2($valor){
            $this->saul2 = $valor;

        }

        
        public function setSaul3($valor){
            $this->saul3 = $valor;

        }
    }    

    //////////////////////////////////////////////////////////////////////////

    
?>