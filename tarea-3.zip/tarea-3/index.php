<?php
    //incluir la clase
    include "promedio.php";

    //instanciar la clase
    $alumnos = new alumnos();
   // $obPro = new alumnos();

    //asignar valores a las propiedades del objeto
    $alumnos->setDiana1(60);
    $alumnos->setDiana2(100);
    $alumnos->setDiana3(100);

        //impresiones de los resultados
        echo"<br> Calificacion1:" .$alumnos->diana1;
        echo"<br> Calificacion 2:" .$alumnos->diana2;
        echo"<br> Calificacion 3" .$alumnos->diana3;

    $alumnos->setIsra1(60);
    $alumnos->setIsra2(100);
    $alumnos->setIsra3(100);

        //impresiones de los resultados
        echo"<br> Calificacion1:" .$alumnos->isra1;
        echo"<br> Calificacion 2:" .$alumnos->isra2;
        echo"<br> Calificacion 3" .$alumnos->isra3;

    $alumnos->setLuis1(60);
    $alumnos->setLuis2(100);
    $alumnos->setLuis3(100);

        //impresiones de los resultados
        echo"<br> Calificacion1:" .$alumnos->luis1;
        echo"<br> Calificacion 2:" .$alumnos->luis2;
        echo"<br> Calificacion 3" .$alumnos->luis3;

    $alumnos->setCesar1(60);
    $alumnos->setCesar2(100);
    $alumnos->setCesar3(100);

        //impresiones de los resultados
        echo"<br> Calificacion1:" .$alumnos->cesar1;
        echo"<br> Calificacion 2:" .$alumnos->cesar2;
        echo"<br> Calificacion 3" .$alumnos->cesar3;

    $alumnos->serMarcelo1(60);
    $alumnos->serMarcelo2(100);
    $alumnos->serMarcelo3(100);

        //impresiones de los resultados
        echo"<br> Calificacion1:" .$alumnos->marcelo1;
        echo"<br> Calificacion 2:" .$alumnos->marcelo2;
        echo"<br> Calificacion 3" .$alumnos->marcelo3;

    $alumnos->setGrecia1(60);
    $alumnos->setGrecia2(100);
    $alumnos->setGrecia3(100);

        //impresiones de los resultados
        echo"<br> Calificacion1:" .$alumnos->grecia1;
        echo"<br> Calificacion 2:" .$alumnos->grecia2;
        echo"<br> Calificacion 3" .$alumnos->grecia3;

    $alumnos->serJaret1(60);
    $alumnos->serJaret2(100);
    $alumnos->serJaret3(100);

        //impresiones de los resultados
        echo"<br> Calificacion1:" .$alumnos->jaret1;
        echo"<br> Calificacion 2:" .$alumnos->jaret2;
        echo"<br> Calificacion 3" .$alumnos->jaret3;

    $alumnos->setJuan1(60);
    $alumnos->setJuan2(100);
    $alumnos->setJuan3(100);

        //impresiones de los resultados
        echo"<br> Calificacion1:" .$alumnos->juan1;
        echo"<br> Calificacion 2:" .$alumnos->juan2;
        echo"<br> Calificacion 3" .$alumnos->juan3;

    $alumnos->setSandra1(60);
    $alumnos->setSandra2(100);
    $alumnos->setSandra3(100);

        //impresiones de los resultados
        echo"<br> Calificacion1:" .$alumnos->sandra1;
        echo"<br> Calificacion 2:" .$alumnos->sandra2;
        echo"<br> Calificacion 3" .$alumnos->sandra3;

    $alumnos->setSaul1(60);
    $alumnos->setSaul2(100);
    $alumnos->setSaul3(100);

        //impresiones de los resultados
        echo"<br> Calificacion1:" .$alumnos->saul1;
        echo"<br> Calificacion 2:" .$alumnos->saul2;
        echo"<br> Calificacion 3" .$alumnos->saul3;

    

?>



