<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Registrar persona</title>
</head>
<body>
	<form method="post" action="conexion.php">
		<label for="matricula">Matricula:</label>
		<br>
		<input name="matricula" required type="int" id="matricula" placeholder="Escribe tu matricula...">
		<br><br>

		<label for="nombre">Nombre:</label>
		<br>
		<input name="nombre" required type="text" id="nombre" placeholder="Escribe tu nombre...">
		<br><br>

        <label for="carrera">Carrera:</label>
		<br>
		<input name="carrera" required type="text" id="carrera" placeholder="Escribe tu carrera...">
		<br><br>

        <label for="email">Email:</label>
		<br>
		<input name="email" required type="text" id="email" placeholder="Escribe tu email...">
		<br><br>

        <label for="telefono">Telefono:</label>
		<br>
		<input name="telefono" required type="text" id="telefono" placeholder="Escribe tu ntelefonoombre...">
		<br><br>


		</select>

		

		<br><br><input type="submit" value="Registrar">
	</form>

</html>


<?
	//incluye la clase Libro y CrudLibro
require_once('crud.php');
require_once('nueva.php');
$crud=new crud();
$Alumnos= new nueva();
//obtiene todos los libros con el método mostrar de la clase crud
$listaAlumnos=$crud->mostrar();
?>

<html>
<head>
	<title>Mostrar Libros</title>
</head>
<body>
	<table border=1>
		<head>
			<td>Matricula</td>
			<td>Nombre</td>
			<td>Carrera</td>
			<td>Email</td>
			<td>Telefono</td>
		</head>
		<body>
			<?php foreach ($listaAlumnos as $crud) {
				
				?>
			<tr>
				<td><?php echo $Alumnos->getMatricula() ?></td>
				<td><?php echo $Alumnos->getNombre() ?></td>
				<td><?php echo $Alumnos->getCarrera()?> </td>
				<td><?php echo $Alumnos->getEmail() ?></td>
				<td><?php echo $Alumnos->getTelefono()?> </td>
				
			</tr>

		</body>
	</table>



</body>
</html>

