<?php
	class alumno{
		private $matricula;
		private $nombre;
		private $carrera;
		private $email;
        private $telefono;

		function __construct(){}

		public function getMatricula(){
		return $this->matricula;
		}

		public function setNombre($matricula){
			$this->matricula = $matricula;
		}

		public function getNombre(){
			return $this->nombre;
		}

		public function setNombre($nombre){
			$this->nombre = $nombre;
		}

		public function getCarrera(){
		return $this->carrera;
		}

		public function setCarrera($carrera){
			$this->carrera = $carrera;
		}
		public function getEmail(){
			return $this->email;
		}

		public function setEmail($email){
			$this->email = $email;
        }
        
        public function getTelefono(){
			return $this->telefono;
		}

		public function setTelefono($telefono){
			$this->telefono = $telefono;
		}
	}
?>