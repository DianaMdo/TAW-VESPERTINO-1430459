<?php
// incluye la clase Db
require_once('conexion.php');

	class CrudAlumno{
		// constructor de la clase
		public function __construct(){}

		// método para insertar, recibe como parámetro un objeto de tipo libro
		public function insertar($alumnos){
			$db=Db::conectar();
			$insert=$db->prepare('INSERT INTO alumnos values(NULL,:matricula,:nombre,:carrera. :email, :telefono)');
            $insert->bindValue('matricula',$alumnos->getMatricula());
            $insert->bindValue('nombre',$alumnos->getNombre());
			$insert->bindValue('carrera',$alumnos->getCarrera());
            $insert->bindValue('email',$alumnos->getEmail());
            $insert->bindValue('telefono',$alumnos->getTelefono());
			$insert->execute();

		}

		// método para mostrar todos los libros
		public function mostrar(){
			$db=Db::conectar();
			$listaAlumnos=[];
			$select=$db->query('SELECT * FROM alumnos');

			foreach($select->fetchAll() as $alumnos){
				$myAlumnos= new Alumno();
				$myAlumnos->setMatricula($alumnos['matricula']);
				$myAlumnos->setNombre($alumnos['nombre']);
				$myAlumnos->setCarrera($alumnos['carrera']);
                $myAlumnos->setEmail($alumnos['email']);
                $myAlumnos->setTelefono($alumnos['telefono']);
				$listaLibros[]=$myAlumnos;
			}
			return $listaAlumnos;
		}


		}
	}
?>